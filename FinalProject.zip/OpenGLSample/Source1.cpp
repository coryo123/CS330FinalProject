
#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "Shader.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#pragma comment(lib,"glfw3.lib")

using namespace std;

//Camera
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

GLfloat deltaTime = 0.0f;
GLfloat lastFrame = 0.0f;


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);


void processInput(GLFWwindow* window);

GLuint Width = 1200, Height = 800;

bool firstMouse = true;
float yaw = -90.0f;	
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0f / 2.0;
float fov = 45.0f;

int main() {
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	GLFWwindow* window = glfwCreateWindow(Width, Height, "LearnOpenGL", NULL, NULL);

	if (window == NULL) {
		cout << "Failed to create GLFW window" << endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);//registration callback function
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		cout << "Failed to initialize GLAD" << endl;
		return -1;
	}



	// Create a vertex cache object to manage the assigned vertex buffer space

	// Create a shader object

		Shader ShaderColor("shader.vs", "shader.frag");


	glEnable(GL_DEPTH_TEST);
	//vertices for triangles
	GLfloat vertices[] = {
		// first triangle texture
		0.5f, -0.5f, -0.5f, 1.0f, 1.0f, // upper right corner
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f, // lower right corner
		-0.5f, -0.5f, -0.5f, 0.0f, 1.0f, // upper left corner
		// second triangle
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f, // lower right corner
		-0.5f, -0.5f, 0.5f, 0.0f, 0.0f, // lower left corner
		-0.5f, -0.5f, -0.5f, 0.0f, 1.0f, // upper left corner
		//The third triangle
		-0.5f, -0.5f, 0.5f, 0.0f, 0.0f, // lower left corner
		  0.0f, 0.2f, 0.0f, 0.5f, 1.0f, // vertex
		0.5f, -0.5f, 0.5f, 1.0f, 0.0f, // lower right corner
		//fourth triangle
		0.5f, -0.5f, 0.5f, 0.0f, 0.0f, // lower right corner
		0.0f, 0.2f, 0.0f, 0.5f, 1.0f, // vertex
		0.5f, -0.5f, -0.5f, 1.0f, 0.0f, // upper right corner
		//The fifth triangle
		0.5f, -0.5f, -0.5f, 0.0f, 0.0f, // upper right corner
		0.0f, 0.2f, 0.0f, 0.5f, 1.0f, // vertex
		-0.5f, -0.5f, -0.5f, 1.0f, 0.0f, // upper left corner
		// sixth triangle
		-0.5f, -0.5f, -0.5f, 0.0f, 0.0f, // upper left corner
		0.0f, 0.2f, 0.0f, 0.5f, 1.0f, // vertex
		-0.5f, -0.5f, 0.5f, 1.0f, 0.0f // lower left corner
	};
	glm::vec3 cubePositions[] = {
		  glm::vec3(0.0f,  0.0f,  0.0f),
		  glm::vec3(1.0f,  1.0f, 0.0f),
		  glm::vec3(-1.5f, -2.2f, -2.5f),
		  glm::vec3(-3.8f, -2.0f, -3.3f),
		  glm::vec3(2.4f, -0.4f, -3.5f),
		  glm::vec3(-1.7f,  3.0f, -7.5f),
		  glm::vec3(1.3f, -2.0f, -2.5f),
		  glm::vec3(1.5f,  2.0f, -2.5f),
		  glm::vec3(1.5f,  0.2f, -1.5f),
		  glm::vec3(-1.3f,  1.0f, -1.5f)
	};

	GLuint VAO, VBO;
	glGenVertexArrays(1, &VAO);//Create vertex array object
	glGenBuffers(1, &VBO);//Create a vertex buffer object

	glBindBuffer(GL_ARRAY_BUFFER, VBO);//bind vertex buffer to vertex buffer object
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);//buffer triangle vertex data



	glBindVertexArray(VAO);//bind a vertex array to a vertex array object
	// Set the vertex attribute pointer

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	//Texture
	GLuint texture[3];
	glGenTextures(3, texture);
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	